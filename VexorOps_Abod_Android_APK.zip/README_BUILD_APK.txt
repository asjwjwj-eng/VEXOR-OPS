=== VEXOR OPS (فيكسور أوبس) — Abod Studio | مشروع APK جاهز ===

اسم التطبيق: VEXOR OPS
معرّف الحزمة: com.abod.vexorops

طريقة البناء عبر GitHub (مجاناً بدون تنصيب برامج):
1. أنشئ مستودعاً جديداً على GitHub باسم: vexor-ops
2. فك ضغط هذا الملف وارفع جميع الملفات والمجلدات (بما فيها مجلد .github).
3. ادخل إلى تبويب Actions وحمّل ملف: VexorOps-Abod-APK (داخله app-debug.apk).
